# Logic Lab for Little Learners — Android starter

A native Android Java app with six interactive logic experiments:
WIRE, NOT, OR, AND, XOR, and LATCH.

## Open and build
1. Extract `LogicLabAndroid.zip`.
2. Open the `LogicLabAndroid` folder in Android Studio.
3. Let Gradle sync. Use JDK 17 and Android SDK Platform 35.
4. Connect an Android phone with USB debugging enabled, or start an emulator.
5. Press Run.

Minimum Android version: Android 5.0 (API 21).
No network permission or online API is used.

## Included in v1
- Kids Mode and Engineering Mode
- Interactive A/B switches and LED output
- Boolean expressions and truth tables in Engineering Mode
- SET/RESET memory controls for the latch
- Reset controls

This is a starter implementation. The next iteration can add illustrations, sound, guided lessons, progress tracking, quizzes, and a polished book-like page flow.

## Build an APK on GitHub

The GitHub Actions workflow is included at `.github/workflows/build-apk.yml`.

1. Create a GitHub repository and upload the **contents** of this project folder.
2. Ensure the default branch is named `main` (or edit the workflow branch filters).
3. Open the repository's **Actions** tab. The workflow runs on every push to `main`, on pull requests, and can be started with **Run workflow**.
4. When it finishes, open the run and download the `LogicLab-debug-apk` artifact. Extract it to get `app-debug.apk`.

The workflow installs Gradle 8.9 and Android SDK 35; no Gradle wrapper files are required. This is a debug APK for testing, not a Play Store release-signed APK.
