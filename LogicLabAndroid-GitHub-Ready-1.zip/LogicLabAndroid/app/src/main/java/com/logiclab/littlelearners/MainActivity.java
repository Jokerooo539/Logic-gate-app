package com.logiclab.littlelearners;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private final String[] gates = {"WIRE", "NOT", "OR", "AND", "XOR", "LATCH"};
    private final String[] descriptions = {
        "A wire carries the signal straight through.",
        "NOT flips the signal: ON becomes OFF, and OFF becomes ON.",
        "OR turns ON when at least one input is ON.",
        "AND turns ON only when both inputs are ON.",
        "XOR turns ON when the inputs are different.",
        "A latch remembers its last SET or RESET command."
    };
    private int gate = 0;
    private boolean a = false, b = false, latch = false, kidsMode = true;
    private LinearLayout root, content, resultCard;
    private TextView output, explanation, inputAText, inputBText, truthTable, modeButton;
    private Button aButton, bButton, setButton, resetButton;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        buildUi();
        render();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    private void pad(View v, int all) { v.setPadding(dp(all), dp(all), dp(all), dp(all)); }
    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h)); }
    private void gap(LinearLayout box, int height) { View v = new View(this); box.addView(v, lp(1,height)); }

    private void buildUi() {
        root = column(); root.setBackgroundColor(Color.rgb(247,247,255));
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        content = column(); content.setPadding(dp(20), dp(18), dp(20), dp(28));
        scroll.addView(content); root.addView(scroll);
        setContentView(root);

        LinearLayout header = row();
        LinearLayout titleCol = column();
        titleCol.addView(text("LOGIC LAB", 13, Color.rgb(108,99,255), true));
        titleCol.addView(text("Little Learners", 27, Color.rgb(32,35,61), true));
        header.addView(titleCol, new LinearLayout.LayoutParams(0, -2, 1));
        modeButton = text("KIDS MODE  ⇄", 13, Color.WHITE, true);
        modeButton.setGravity(Gravity.CENTER); modeButton.setPadding(dp(14),dp(12),dp(14),dp(12));
        modeButton.setBackground(bg(Color.rgb(108,99,255), 18));
        modeButton.setOnClickListener(v -> { kidsMode = !kidsMode; render(); });
        header.addView(modeButton);
        content.addView(header);
        gap(content, 18);

        TextView intro = text("Play with real digital logic. Tap the switches and watch the light!", 15, Color.rgb(91,95,120), false);
        content.addView(intro);
        gap(content, 18);

        TextView gateLabel = text("CHOOSE A LOGIC EXPERIMENT", 12, Color.rgb(110,112,140), true);
        content.addView(gateLabel); gap(content, 8);
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, gates);
        spinner.setAdapter(adapter); spinner.setSelection(gate);
        spinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(android.widget.AdapterView<?> p) {}
            public void onItemSelected(android.widget.AdapterView<?> p, View v, int position, long id) {
                if (gate != position) { gate = position; render(); }
            }
        });
        content.addView(spinner, lp(-1, 52));
        gap(content, 14);

        LinearLayout lesson = column(); lesson.setBackground(bg(Color.WHITE, 22)); pad(lesson,18);
        lesson.addView(text("TODAY'S EXPERIMENT", 11, Color.rgb(108,99,255), true));
        gap(lesson, 5);
        lesson.addView(text(gates[gate] + " GATE", 23, Color.rgb(32,35,61), true));
        gap(lesson, 6);
        lesson.addView(text(descriptions[gate], 15, Color.rgb(91,95,120), false));
        content.addView(lesson);
        gap(content, 14);

        LinearLayout inputs = column(); inputs.setBackground(bg(Color.WHITE,22)); pad(inputs,18);
        inputs.addView(text("INPUT SWITCHES", 12, Color.rgb(110,112,140), true));
        gap(inputs, 12);
        LinearLayout inputRow = row();
        LinearLayout aCol = column(), bCol = column();
        inputAText = text("INPUT A · OFF", 14, Color.rgb(32,35,61), true);
        inputBText = text("INPUT B · OFF", 14, Color.rgb(32,35,61), true);
        aButton = new Button(this); bButton = new Button(this);
        aButton.setOnClickListener(v -> { a = !a; render(); });
        bButton.setOnClickListener(v -> { b = !b; render(); });
        aCol.addView(inputAText); aCol.addView(aButton, lp(-1,52));
        bCol.addView(inputBText); bCol.addView(bButton, lp(-1,52));
        inputRow.addView(aCol, new LinearLayout.LayoutParams(0,-2,1));
        View spacer = new View(this); inputRow.addView(spacer, lp(12,1));
        inputRow.addView(bCol, new LinearLayout.LayoutParams(0,-2,1));
        inputs.addView(inputRow);
        gap(inputs, 8);
        LinearLayout latchRow = row();
        setButton = new Button(this); setButton.setText("SET  ·  Remember ON");
        resetButton = new Button(this); resetButton.setText("RESET  ·  Remember OFF");
        setButton.setOnClickListener(v -> { latch = true; render(); });
        resetButton.setOnClickListener(v -> { latch = false; render(); });
        latchRow.addView(setButton, new LinearLayout.LayoutParams(0,-2,1));
        latchRow.addView(resetButton, new LinearLayout.LayoutParams(0,-2,1));
        inputs.addView(latchRow);
        content.addView(inputs);
        gap(content, 14);

        resultCard = column(); resultCard.setBackground(bg(Color.rgb(32,35,61),22)); pad(resultCard,20);
        resultCard.addView(text("OUTPUT", 12, Color.rgb(193,190,255), true));
        gap(resultCard, 8);
        output = text("●  LED OFF", 26, Color.WHITE, true);
        output.setGravity(Gravity.CENTER);
        resultCard.addView(output, lp(-1,78));
        explanation = text("", 14, Color.WHITE, false);
        explanation.setGravity(Gravity.CENTER);
        resultCard.addView(explanation);
        content.addView(resultCard);
        gap(content, 14);

        LinearLayout theory = column(); theory.setBackground(bg(Color.WHITE,22)); pad(theory,18);
        theory.addView(text("ENGINEERING VIEW", 12, Color.rgb(108,99,255), true));
        gap(theory,8);
        truthTable = text("", 14, Color.rgb(48,51,76), false);
        theory.addView(truthTable);
        content.addView(theory);
        gap(content, 14);

        Button reset = new Button(this); reset.setText("↻  RESET INPUTS");
        reset.setOnClickListener(v -> { a=false; b=false; latch=false; render(); });
        content.addView(reset, lp(-1,52));
        gap(content, 10);
        content.addView(text("Learn by playing • No internet needed • Version 1.0", 12, Color.rgb(130,132,154), false));
    }

    private boolean value() {
        switch(gate) {
            case 0: return a;
            case 1: return !a;
            case 2: return a || b;
            case 3: return a && b;
            case 4: return a ^ b;
            default: return latch;
        }
    }
    private String bit(boolean x) { return x ? "1" : "0"; }
    private void render() {
        if (content == null) return;
        // Update existing views without rebuilding the spinner or losing selection.
        if (modeButton != null) modeButton.setText(kidsMode ? "KIDS MODE  ⇄" : "ENGINEERING  ⇄");
        if (inputAText != null) inputAText.setText("INPUT A · " + (a ? "ON" : "OFF"));
        if (inputBText != null) inputBText.setText("INPUT B · " + (b ? "ON" : "OFF"));
        if (aButton != null) { aButton.setText(a ? "●  ON" : "○  OFF"); aButton.setBackgroundTintList(android.content.res.ColorStateList.valueOf(a ? Color.rgb(63,190,137) : Color.rgb(225,228,240))); }
        if (bButton != null) { bButton.setText(b ? "●  ON" : "○  OFF"); bButton.setBackgroundTintList(android.content.res.ColorStateList.valueOf(b ? Color.rgb(63,190,137) : Color.rgb(225,228,240))); }
        boolean out = value();
        if (output != null) { output.setText(out ? "●  LED ON" : "○  LED OFF"); output.setTextColor(out ? Color.rgb(116,255,190) : Color.rgb(215,218,235)); }
        if (explanation != null) {
            String simple = out ? "The light is glowing! Great job!" : "The light is resting. Try another switch!";
            String technical = gates[gate] + " output = " + bit(out) + "  (A=" + bit(a) + ", B=" + bit(b) + ")";
            explanation.setText(kidsMode ? simple : technical);
        }
        if (setButton != null) { setButton.setVisibility(gate == 5 ? View.VISIBLE : View.GONE); resetButton.setVisibility(gate == 5 ? View.VISIBLE : View.GONE); }
        if (bButton != null) bButton.setEnabled(gate == 2 || gate == 3 || gate == 4);
        if (inputBText != null) inputBText.setAlpha((gate == 2 || gate == 3 || gate == 4) ? 1f : .35f);
        if (truthTable != null) {
            if (kidsMode) truthTable.setText("Switch the mode above to see the truth table and Boolean expression.");
            else truthTable.setText(tableText());
        }
        // Update experiment heading and description by locating text labels in the lesson card.
        updateLessonLabels();
    }
    private void updateLessonLabels() {
        // Rebuild only the lesson description block by scanning the card's text children.
        for (int i=0; i<content.getChildCount(); i++) {
            View v = content.getChildAt(i);
            if (v instanceof LinearLayout) {
                LinearLayout box = (LinearLayout)v;
                for (int j=0; j<box.getChildCount(); j++) {
                    View child = box.getChildAt(j);
                    if (child instanceof TextView) {
                        TextView t = (TextView)child;
                        if (t.getText().toString().endsWith(" GATE")) t.setText(gates[gate] + " GATE");
                        if (j == 4 && i > 0) t.setText(descriptions[gate]);
                    }
                }
            }
        }
    }
    private String tableText() {
        String expr;
        switch(gate) {
            case 0: expr = "Y = A"; break;
            case 1: expr = "Y = NOT A"; break;
            case 2: expr = "Y = A OR B"; break;
            case 3: expr = "Y = A AND B"; break;
            case 4: expr = "Y = A XOR B"; break;
            default: expr = "Q(next) = SET ? 1 : RESET ? 0 : Q(previous)"; break;
        }
        StringBuilder s = new StringBuilder("Boolean rule: " + expr + "\n\nA    B    Y\n");
        if (gate == 5) return s + "SET    RESET    Q(next)\n 0        0          Q(previous)\n 1        0          1\n 0        1          0";
        if (gate == 1) return s + "0    –    1\n1    –    0";
        if (gate == 0) return s + "0    –    0\n1    –    1";
        for (int x=0;x<=1;x++) for(int y=0;y<=1;y++) {
            boolean z = gate==2 ? (x==1 || y==1) : gate==3 ? (x==1 && y==1) : (x!=y);
            s.append(x).append("    ").append(y).append("    ").append(z?1:0).append("\n");
        }
        return s.toString();
    }
}
